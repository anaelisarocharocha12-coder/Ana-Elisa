const formulario = document.querySelector("form");
formulario.addEventListener("submit", function(event) {
    event.preventDefault();
    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;
    const mensagem = document.getElementById("mensagem").value;
    if (nome.trim() === "" || email.trim() === "" || mensagem.trim() === "") {
        alert("Por favor, preencha todos os campos.");
        return;
    }
    if (!email.includes("@") || !email.includes(".")) {
        alert("Por favor, informe um e-mail válido.");
        return;
    }
    alert("Obrigada pelo contato, " + nome + "! A ELORA PARFUM agradece sua mensagem.");
    formulario.reset();
});